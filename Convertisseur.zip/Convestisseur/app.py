from flask import Flask, render_template
import os
from datetime import datetime, timedelta
import random

app = Flask(__name__)

def generate_historical_data(current_rate: float, days: int = 7):
    """Génère des données fictives sur N jours avec ±1% de fluctuation."""
    today = datetime.now()
    data = []
    for i in range(days-1, -1, -1):
        dt = today - timedelta(days=i)
        fluctuation = (random.random() - 0.5) * 0.02  # ±1%
        rate = round(current_rate * (1 + fluctuation), 4)
        data.append({
            "date": dt.strftime("%a"),  # lun, mar, ...
            "rate": rate
        })
    return data

def analyze_trend(series):
    """Retourne {'trend': 'up'|'down'|'stable', 'change': 'x.xx'}"""
    if not series or len(series) < 2:
        return {"trend": "stable", "change": "0.00"}
    first = series[0]["rate"]
    last = series[-1]["rate"]
    change = 0 if first == 0 else ((last - first) / first) * 100
    if change > 1:
        return {"trend": "up", "change": f"{change:.2f}"}
    if change < -1:
        return {"trend": "down", "change": f"{change:.2f}"}
    return {"trend": "stable", "change": f"{change:.2f}"}

@app.route("/")
def index():
    # Taux fictifs (mêmes valeurs que ton code React)
    exchange_rates = {
        "MAD": {
            "USD": 0.098, 
            "EUR": 0.092, 
            "GBP": 0.079,
            "MAD": 1.0
        },
        "USD": {
            "MAD": 10.20,
            "EUR": 0.94,
            "GBP": 0.81,
            "USD": 1.0
        },
        "EUR": {
            "MAD": 10.87,
            "USD": 1.06,
            "GBP": 0.86,
            "EUR": 1.0
        },
        "GBP": {
            "MAD": 12.66,
            "USD": 1.23,
            "EUR": 1.16,
            "GBP": 1.0
        }
    }

    historical_data = {
        "USD": generate_historical_data(exchange_rates["MAD"]["USD"]),
        "EUR": generate_historical_data(exchange_rates["MAD"]["EUR"]),
        "GBP": generate_historical_data(exchange_rates["MAD"]["GBP"]),
    }

    trends = {code: analyze_trend(historical_data[code]) for code in ["USD", "EUR", "GBP"]}

    currencies = [
        {"code": "USD", "name": "Dollar US", "color": "#10B981"},
        {"code": "EUR", "name": "Euro", "color": "#3B82F6"},
        {"code": "GBP", "name": "Livre Sterling", "color": "#8B5CF6"},
    ]
    
    return render_template('index.html',
                         last_updated=datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
                         exchange_rates=exchange_rates,
                         historical_data=historical_data,
                         trends=trends,
                         currencies=currencies)

if __name__ == '__main__':
    port = int(os.environ.get("PORT", 5001))
    host = os.environ.get("HOST", "127.0.0.1")
    debug_env = os.environ.get("FLASK_DEBUG") or os.environ.get("DEBUG")
    debug = True if (debug_env is None or str(debug_env).lower() in {"1", "true", "yes"}) else False
    print(f"🚀 Application lancée sur http://{host}:{port}")
    app.run(debug=debug, host=host, port=port)
