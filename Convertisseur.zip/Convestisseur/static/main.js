// main.js — initialize charts and converter
document.addEventListener('DOMContentLoaded', function(){
  try{
    // HISTORICAL_DATA, EXCHANGE_RATES, CURRENCIES are injected by Jinja in the page before this script
    // Charts
    (CURRENCIES || []).forEach((c)=>{
      const ctx = document.getElementById(`chart${c.code}`);
      if (!ctx) return;
      const series = (HISTORICAL_DATA && HISTORICAL_DATA[c.code]) || [];
      new Chart(ctx, {
        type: 'line',
        data: {
          labels: series.map(p=>p.date),
          datasets: [{
            label: `1 MAD en ${c.code}`,
            data: series.map(p=>p.rate),
            borderColor: c.color,
            backgroundColor: (() => {
              const gradient = ctx.getContext('2d').createLinearGradient(0, 0, 0, 400);
              gradient.addColorStop(0, c.color + '40');
              gradient.addColorStop(1, c.color + '00');
              return gradient;
            })(),
            borderWidth: 2,
            tension: 0.4,
            fill: true,
            pointRadius: 0,
            pointHoverRadius: 8,
            pointBackgroundColor: '#fff',
            pointBorderColor: c.color,
            pointBorderWidth: 2,
            pointHoverBorderWidth: 3,
            pointHoverBackgroundColor: '#fff',
            pointHoverBorderColor: c.color
          }]
        },
        options: { 
          responsive: true,
          maintainAspectRatio: false,
          interaction: {
            intersect: false,
            mode: 'index'
          },
          plugins: { 
            legend: { display: false },
            tooltip: {
              backgroundColor: 'rgba(255, 255, 255, 0.98)',
              titleColor: '#1e293b',
              bodyColor: '#475569',
              borderColor: '#e2e8f0',
              borderWidth: 1,
              padding: 12,
              cornerRadius: 8,
              displayColors: false,
              titleFont: {
                size: 13,
                weight: '600',
                family: "'Inter', sans-serif"
              },
              bodyFont: {
                size: 12,
                family: "'Inter', sans-serif"
              },
              callbacks: {
                title: function(context) {
                  return context[0].label;
                },
                label: function(context) {
                  return `1 MAD = ${context.parsed.y.toFixed(4)} ${c.code}`;
                }
              }
            }
          },
          scales: {
            y: {
              beginAtZero: false,
              grid: {
                color: '#f1f5f9',
                drawBorder: false,
                lineWidth: 1
              },
              border: {
                display: false
              },
              ticks: {
                color: '#94a3b8',
                font: { 
                  size: 11,
                  family: "'Inter', sans-serif"
                },
                padding: 8
              }
            },
            x: {
              grid: {
                display: false
              },
              border: {
                display: false
              },
              ticks: {
                color: '#94a3b8',
                font: { 
                  size: 11,
                  family: "'Inter', sans-serif"
                },
                padding: 8
              }
            }
          }
        }
      });
    });

    // Converter
    const amountEl = document.getElementById('amount');
    const fromEl = document.getElementById('fromCurrency');
    const toEl = document.getElementById('toCurrency');
    const resultEl = document.getElementById('result');
    const rateInfoEl = document.getElementById('rateInfo');
    const swapBtn = document.getElementById('swapBtn');

    function computeConversion(){
      const amount = parseFloat(amountEl.value) || 0;
      const from = fromEl.value;
      const to = toEl.value;
      let value = 0;
      let rateText = '—';

      if (from === to){ value = amount; rateText = `1 ${from} = 1 ${to}`; }
      else if (from === 'MAD' && EXCHANGE_RATES.MAD && EXCHANGE_RATES.MAD[to]){
        value = amount * EXCHANGE_RATES.MAD[to];
        rateText = `1 MAD = ${EXCHANGE_RATES.MAD[to].toFixed(4)} ${to}`;
      } else if (to === 'MAD' && EXCHANGE_RATES[from] && EXCHANGE_RATES[from].MAD){
        value = amount * EXCHANGE_RATES[from].MAD;
        rateText = `1 ${from} = ${EXCHANGE_RATES[from].MAD.toFixed(4)} MAD`;
      } else {
        const toMAD = EXCHANGE_RATES[from]?.MAD || 0;
        const fromMAD = EXCHANGE_RATES.MAD?.[to] || 0;
        value = amount * toMAD * fromMAD;
        rateText = `1 ${from} = ${toMAD.toFixed(4)} MAD ; 1 MAD = ${fromMAD.toFixed(4)} ${to}`;
      }

      if (resultEl) resultEl.textContent = `${value.toFixed(2)} ${to}`;
      if (rateInfoEl) rateInfoEl.textContent = `Taux utilisé: ${rateText}`;
    }

    ['input','change'].forEach(evt=>{
      if (amountEl) amountEl.addEventListener(evt, computeConversion);
      if (fromEl) fromEl.addEventListener(evt, computeConversion);
      if (toEl) toEl.addEventListener(evt, computeConversion);
    });

    if (swapBtn) swapBtn.addEventListener('click', function(){
      const a = fromEl.value; fromEl.value = toEl.value; toEl.value = a; computeConversion();
    });

    // initial compute
    computeConversion();
  }catch(e){ console.error('main.js error', e); }
});
