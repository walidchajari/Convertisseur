// Fonction de conversion
function convert() {
    const amount = parseFloat(document.getElementById('amount').value);
    const fromCurrency = document.getElementById('from').value;
    const toCurrency = document.getElementById('to').value;

    if (isNaN(amount)) {
        document.getElementById('result').textContent = '--';
        document.getElementById('rate').textContent = '--';
        return;
    }

    let rate;
    if (fromCurrency === toCurrency) {
        rate = 1;
    } else if (fromCurrency === 'MAD') {
        rate = EXCHANGE_RATES.MAD[toCurrency];
    } else if (toCurrency === 'MAD') {
        rate = EXCHANGE_RATES[fromCurrency].MAD;
    } else {
        // Conversion via MAD
        const toMAD = EXCHANGE_RATES[fromCurrency].MAD;
        const fromMADtoTarget = EXCHANGE_RATES.MAD[toCurrency];
        rate = toMAD * fromMADtoTarget;
    }

    const result = amount * rate;
    document.getElementById('result').textContent = `${result.toFixed(4)} ${toCurrency}`;
    document.getElementById('rate').textContent = `1 ${fromCurrency} = ${rate.toFixed(4)} ${toCurrency}`;
}

// Ajouter les écouteurs d'événements
document.addEventListener('DOMContentLoaded', function() {
    const inputs = ['amount', 'from', 'to'];
    inputs.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            element.addEventListener('change', convert);
            element.addEventListener('input', convert);
        }
    });
    
    // Conversion initiale
    convert();
});